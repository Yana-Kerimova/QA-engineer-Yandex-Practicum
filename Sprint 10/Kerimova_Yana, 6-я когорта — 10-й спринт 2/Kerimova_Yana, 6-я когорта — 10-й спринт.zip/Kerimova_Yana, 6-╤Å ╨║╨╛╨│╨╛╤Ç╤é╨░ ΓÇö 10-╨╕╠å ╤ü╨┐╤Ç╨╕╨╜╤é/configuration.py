URL_SERVICE = "https://a1522baf-a814-4598-9759-66b6cc8492fe.serverhub.praktikum-services.ru"
CREATE_USER_PATH = "/api/v1/users/"
KITS_PATH = "/api/v1/kits/"
